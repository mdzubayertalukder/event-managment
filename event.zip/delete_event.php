<?php
include 'db.php';

// Check if an ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM events WHERE id = $id";
    if ($conn->query($sql)) {
        header('Location: admin_dashboard.php?view=events');
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}
?>
