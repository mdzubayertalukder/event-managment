<?php
// Include the database connection
include 'db.php';

// Check if an ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM events WHERE id = $id";
    $result = $conn->query($sql);
    $event = $result->fetch_assoc();

    // Update event if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $date_time = $_POST['date_time'];
        $location = $_POST['location'];
        $registration_fee = $_POST['registration_fee'];
        
        // Handle image upload
        $image = $event['image']; // Keep the existing image by default
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "uploads/";
            $image = $target_dir . basename($_FILES["image"]["name"]);
            move_uploaded_file($_FILES["image"]["tmp_name"], $image);
        }

        // Update the event in the database
        $sql = "UPDATE events SET title = '$title', description = '$description', date_time = '$date_time', location = '$location', image = '$image', registration_fee = '$registration_fee' WHERE id = $id";
        if ($conn->query($sql)) {
            header('Location: admin_dashboard.php?view=events');
        } else {
            echo "<p>Error: " . $conn->error . "</p>";
        }
    }
}
?>

<h2>Edit Event</h2>
<form method="POST" enctype="multipart/form-data">
    <label>Title:</label>
    <input type="text" name="title" value="<?= $event['title'] ?>" required><br><br>
    
    <label>Description:</label>
    <textarea name="description" required><?= $event['description'] ?></textarea><br><br>
    
    <label>Date and Time:</label>
    <input type="datetime-local" name="date_time" value="<?= date('Y-m-d\TH:i', strtotime($event['date_time'])) ?>" required><br><br>
    
    <label>Location:</label>
    <input type="text" name="location" value="<?= $event['location'] ?>" required><br><br>
    
    <label>Registration Fee:</label>
    <input type="number" step="0.01" name="registration_fee" value="<?= $event['registration_fee'] ?>" required><br><br>
    
    <label>Image:</label>
    <input type="file" name="image"><br><br>
    
    <button type="submit">Update Event</button>
</form>
