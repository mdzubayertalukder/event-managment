<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventify - Comprehensive Event Management Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2ecc71;
            --accent-color: #e74c3c;
            --dark-color: #2c3e50;
            --light-color: #ecf0f1;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            color: var(--dark-color);
            background-color: #f4f6f7;
        }

        .container {
    width: 100%; /* Full width */
    margin: 0 auto; /* Center alignment */
    padding: 0 20px; /* Optional: Add padding for some space on the sides */
}


        /* Header and Navigation */
        .header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px 0;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 700;
            color: white;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 30px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-links a:hover {
            color: var(--light-color);
        }

        .cta-buttons {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background-color: white;
            color: var(--primary-color);
        }

        .btn-secondary {
            background-color: transparent;
            border: 2px solid white;
            color: white;
        }

        /* Hero Section */
        .hero {
            display: flex;
            align-items: center;
            padding: 100px 0;
            background-color: rgba(255,255,255,0.9);
        }

        .hero-content {
            flex: 1;
            padding-right: 50px;
        }

        .hero-content h1 {
            font-size: 48px;
            color: var(--dark-color);
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 18px;
            color: #6c757d;
            margin-bottom: 30px;
        }

        .hero-image {
            flex: 1;
            text-align: right;
        }

        .hero-image img {
            max-width: 100%;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
        }

        /* Features Section */
        .features {
            background-color: white;
            padding: 80px 0;
            text-align: center;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 50px;
        }

        .feature-card {
            background-color: var(--light-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }

        .feature-card:hover {
            transform: translateY(-10px);
        }

        .feature-card h3 {
            margin-bottom: 15px;
            color: var(--primary-color);
        }

        /* Value Propositions */
        .value-props {
            display: flex;
            background-color: var(--light-color);
            padding: 80px 0;
        }

        .value-prop {
            flex: 1;
            text-align: center;
            padding: 20px;
        }

        .value-prop i {
            font-size: 48px;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        /* Event Types */
        .event-types {
            background-color: white;
            padding: 80px 0;
            text-align: center;
        }

        .event-types-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-top: 40px;
        }

        .event-type {
            background-color: var(--light-color);
            padding: 20px;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }

        .event-type:hover {
            transform: scale(1.05);
        }

        /* Testimonials */
        .testimonials {
            background-color: var(--primary-color);
            color: white;
            padding: 80px 0;
            text-align: center;
        }

        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 40px;
        }

        .testimonial-card {
            background-color: rgba(255,255,255,0.1);
            padding: 25px;
            border-radius: 10px;
        }

        /* Footer */
        .footer {
            background-color: var(--dark-color);
            color: white;
            padding: 50px 0;
            text-align: center;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
        }

        .footer-links a {
            color: white;
            text-decoration: none;
        }

        /* Events Section */
.events-grid {
    padding: 50px 0;
    background-color: white;
    text-align: center;
}

.event-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 20px;
    background-color: var(--light-color);
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    margin: 20px auto;
    max-width: 400px;
}

.event-image {
    width: 100%;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.event-title {
    font-size: 22px;
    color: var(--primary-color);
    margin: 10px 0;
}

.event-meta {
    color: #555;
    font-size: 16px;
    text-align: left;
}

.event-fee {
    color: var(--accent-color);
    font-weight: bold;
}

.btn-primary {
    background-color: var(--primary-color);
    color: white;
    padding: 10px 20px;
    border-radius: 50px;
    text-decoration: none;
    transition: background-color 0.3s ease;
}

.btn-primary:hover {
    background-color: var(--dark-color);
}

    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container navbar">
            <a href="#" class="logo">Eventify</a>
            <nav class="nav-links">
                <a href="#">Home</a>
                <a href="#">Services</a>
                <a href="#">Events</a>
                <a href="#">About Us</a>
                <a href="#">Contact</a>
            </nav>
            <div class="cta-buttons">
                <a href="#" class="btn btn-secondary">Login</a>
                <a href="#" class="btn btn-primary">Register</a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero container">
        <div class="hero-content">
            <h1>Simplify Event Management, Amplify Experiences</h1>
            <p>Eventify is your all-in-one platform designed to streamline event planning, boost attendee engagement, and create memorable experiences for organizers and participants alike.</p>
            <a href="#" class="btn btn-primary">Get Started</a>
        </div>
        <div class="hero-image">
            <img src="https://source.unsplash.com/random/800x600?event,conference" alt="Event Management Platform">
        </div>
    </section>

    <!-- Features Section -->
    <section class="features container">
        <h2>Our Key Features</h2>
        <p>Powerful tools to make event management seamless and efficient</p>
        <div class="features-grid">
            <div class="feature-card">
                <h3>Easy Registration</h3>
                <p>Streamlined registration process with custom forms, ticketing, and payment integration.</p>
            </div>
            <div class="feature-card">
                <h3>Event Marketing</h3>
                <p>Comprehensive marketing tools to promote your events and maximize attendance.</p>
            </div>
            <div class="feature-card">
                <h3>Real-time Analytics</h3>
                <p>Detailed insights and reporting to track event performance and attendee engagement.</p>
            </div>
        </div>
    </section>


    <section class="events-grid container">
    <h2>Upcoming Events</h2>
    <p>Discover exciting events happening near you.</p>
    <div class="event-card">
        <img src="https://source.unsplash.com/random/800x600?tech,conference" alt="Tech Innovation Summit" class="event-image">
        <div class="event-details">
            <h3 class="event-title">Tech Innovation Summit</h3>
            <p class="event-meta">
                📅 <strong>Date:</strong> Sep 20-22, 2024<br>
                ⏰ <strong>Time:</strong> 9:00 AM - 6:00 PM
            </p>
            <p class="event-fee">
                💵 <strong>Entry Fee:</strong> $50
            </p>
            <a href="#" class="btn btn-primary">Book Now</a>
        </div>
    </div>
</section>



    
    <!-- Value Propositions -->
    <section class="value-props container">
        <div class="value-prop">
            <i>🌐</i>
            <h3>Global Reach</h3>
            <p>Connect with attendees worldwide, breaking geographical barriers.</p>
        </div>
        <div class="value-prop">
            <i>💡</i>
            <h3>Smart Solutions</h3>
            <p>Innovative technologies to simplify complex event management tasks.</p>
        </div>
        <div class="value-prop">
            <i>🤝</i>
            <h3>Seamless Collaboration</h3>
            <p>Easy team coordination and communication throughout the event lifecycle.</p>
        </div>
    </section>

    <!-- Event Types -->
    <section class="event-types container">
        <h2>Events We Support</h2>
        <p>Versatile platform catering to diverse event types and industries</p>
        <div class="event-types-grid">
            <div class="event-type">
                <h3>Conferences</h3>
            </div>
            <div class="event-type">
                <h3>Workshops</h3>
            </div>
            <div class="event-type">
                <h3>Concerts</h3>
            </div>
            <div class="event-type">
                <h3>Seminars</h3>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials container">
        <h2>What Our Users Say</h2>
        <p>Real experiences from event organizers who trust Eventify</p>
        <div class="testimonial-grid">
            <div class="testimonial-card">
                <p>"Eventify transformed how we manage our annual conference. Incredibly intuitive!"</p>
                <h4>Sarah Johnson</h4>
                <p>Corporate Event Planner</p>
            </div>
            <div class="testimonial-card">
                <p>"The marketing tools are game-changing. We saw a 40% increase in event attendance."</p>
                <h4>Michael Chen</h4>
                <p>Tech Conference Organizer</p>
            </div>
            <div class="testimonial-card">
                <p>"Seamless registration and real-time analytics make event planning a breeze."</p>
                <h4>Emma Rodriguez</h4>
                <p>Nonprofit Event Coordinator</p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-links">
                <a href="#">Home</a>
                <a href="#">Services</a>
                <a href="#">Events</a>
                <a href="#">About Us</a>
                <a href="#">Contact</a>
            </div>
            <p>&copy; 2024 Eventify. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>