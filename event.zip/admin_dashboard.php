<?php
session_start();
include 'db.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Fetch all user data
$sql = "SELECT full_name, email, role FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }
        .sidebar {
            width: 20%;
            background: #333;
            color: #fff;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        .sidebar a {
            display: block;
            color: #fff;
            padding: 15px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #575757;
        }
        .content {
            margin-left: 20%;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        table th {
            background: #007BFF;
            color: #fff;
        }
        button.logout {
            background: #ff4d4d;
            border: none;
            padding: 10px;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }
        button.logout:hover {
            background: #cc0000;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2 style="text-align: center;">Admin Panel</h2>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="admin_dashboard.php?view=users">All Users</a>
        <a href="admin_dashboard.php?view=events">Event List</a>
        <a href="admin_dashboard.php?view=seating">Home Page Seating</a>
        <a href="admin_dashboard.php?view=account">Account Settings</a>
        <a href="logout.php">Log Out</a>
    </div>
    <div class="content">
        <h1>Welcome, Admin</h1>

        <?php
        // Check the view parameter to display content
        if (isset($_GET['view']) && $_GET['view'] === 'users') {
            echo "<h2>All Users</h2>";
            echo "<table>";
            echo "<tr><th>Full Name</th><th>Email</th><th>Role</th></tr>";

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr><td>{$row['full_name']}</td><td>{$row['email']}</td><td>{$row['role']}</td></tr>";
                }
            } else {
                echo "<tr><td colspan='3'>No users found</td></tr>";
            }
            echo "</table>";
        } elseif (isset($_GET['view']) && $_GET['view'] === 'events') {
           
            // Fetch all events and display them
            if (isset($_GET['view']) && $_GET['view'] === 'events') {
                echo "<h2>Event List</h2>";
                
                $sql = "SELECT * FROM events";
                $result = $conn->query($sql);
                
                echo "<table>";
                echo "<tr><th>Title</th><th>Date</th><th>Location</th><th>Fee</th><th>Actions</th></tr>";
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$row['title']}</td>";
                        echo "<td>{$row['date_time']}</td>";
                        echo "<td>{$row['location']}</td>";
                        echo "<td>{$row['registration_fee']}</td>";
                        echo "<td>
                                <a href='edit_event.php?id={$row['id']}'>Edit</a> | 
                                <a href='delete_event.php?id={$row['id']}' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No events found</td></tr>";
                }
                echo "</table>";
            }
            
            
        } elseif (isset($_GET['view']) && $_GET['view'] === 'seating') {
            echo "<h2>Home Page Seating</h2>";
            echo "<p>Home page seating management section will be here.</p>";
        } elseif (isset($_GET['view']) && $_GET['view'] === 'account') {
            echo "<h2>Account Settings</h2>";
            echo "<p>Account settings section will be here.</p>";
        } else {
            echo "<p>Select an option from the sidebar to view details.</p>";
        }
        ?>
    </div>
    <div>
    <?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $date_time = $_POST['date_time'];
    $location = $_POST['location'];
    $registration_fee = $_POST['registration_fee'];
    
    // Handle file upload
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "uploads/";
        $image = $target_dir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $image);
    }

    $sql = "INSERT INTO events (title, description, date_time, location, image, registration_fee)
            VALUES ('$title', '$description', '$date_time', '$location', '$image', '$registration_fee')";
    if ($conn->query($sql)) {
        echo "<p>Event created successfully!</p>";
    } else {
        echo "<p>Error: " . $conn->error . "</p>";
    }
}
?>

<h2>Create Event</h2>
<form method="POST" enctype="multipart/form-data">
    <label>Title:</label>
    <input type="text" name="title" required><br><br>
    
    <label>Description:</label>
    <textarea name="description" required></textarea><br><br>
    
    <label>Date and Time:</label>
    <input type="datetime-local" name="date_time" required><br><br>
    
    <label>Location:</label>
    <input type="text" name="location" required><br><br>
    
    <label>Registration Fee:</label>
    <input type="number" step="0.01" name="registration_fee" required><br><br>
    
    <label>Image:</label>
    <input type="file" name="image"><br><br>
    
    <button type="submit" name="add_event">Create Event</button>
</form>

    </div>
</body>
</html>
